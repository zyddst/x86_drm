import mmap
import numpy as np
from PIL import Image
import argparse
import time

def parse_args():
    parser = argparse.ArgumentParser(description='virtual dispaly tool')
    #parser.add_argument('case', type=str, help='Case to run')
    parser.add_argument('-B', '--address', type=str, help='buffer address')
    parser.add_argument('-W', '--width', type=str, help='width')
    parser.add_argument('-H', '--height', type=str, help='height')
    args = parser.parse_args()
    args.parser = parser
    return args

def clear_buffer(phy, w, h):
    with open('/dev/mem', 'r+b') as mem:
        offset = phy
        size = w*h*4
        mem_mapped = mmap.mmap(mem.fileno(), size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE, offset=offset)
        zeros = bytearray(size)
        mem_mapped.write(zeros)
        mem_mapped.close()
        return

args = parse_args()
if args.address and args.width and args.height:
    phy = int(args.address, 16)
    width = int(args.width)
    height = int(args.height)
    clear_buffer(phy, width, height)
else:
    args.parser.print_help()
#phy = int(input("please input phy address:"), 16)
#width = int(input("Please input width:"))
#height = int(input("Please input height:"))


