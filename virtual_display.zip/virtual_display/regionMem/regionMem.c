//kernel space
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/ioport.h>
#include <linux/io.h>
MODULE_LICENSE("GPL");
MODULE_AUTHOR("RAO");

#define MEM_REGION_START 0x10000000
#define SIZE (4096 * 2160 * 8)

static int my_init(void)
{
	void *mem_start = NULL;
	struct resource *mem_resource = NULL;
	mem_resource = request_mem_region(MEM_REGION_START, SIZE, "virtual display buffer region");
	if (!mem_resource) {
		printk("Failed to alloc buffer.\n");
		return -ENXIO;
	}

	mem_start = ioremap(mem_resource->start, SIZE);
	if (!mem_start) {
		printk("failed to map phy buffer.\n");
		release_mem_region(MEM_REGION_START, SIZE);
		return -ENXIO;
	}
	memset(mem_start, 0, SIZE);
	printk("buffer pyh address:0x%llx, size = %d.\n", mem_resource->start, SIZE);
	return 0;
}

static void my_exit(void)
{
	release_mem_region(MEM_REGION_START, SIZE);
	printk("buffer free exit.\n");
	return;
}

module_init(my_init);
module_exit(my_exit);
