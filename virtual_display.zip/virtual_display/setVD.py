import mmap
import struct
import numpy as np
from PIL import Image
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description='virtual dispaly set tool')
    #parser.add_argument('case', type=str, help='Case to run')
    parser.add_argument('-V', '--address', type=str, help='virtual display address')
    parser.add_argument('-B', '--buffer', type=str, help='buffer address')
    parser.add_argument('-W', '--width', type=str, help='width')
    parser.add_argument('-H', '--height', type=str, help='height')
    args = parser.parse_args()
    args.parser = parser
    return args

def get_buffer_address(buffer):
    address = buffer.__array_interface__['data'][0]
    return hex(address)

def alloc_buffer(size):
    buffer = np.zeros(size, dtype=np.uint8)
    return buffer

def map_phy_addr(phy, buffer_addr, w, h):
    with open('/dev/mem', 'r+b') as mem:
        offset = phy
        offset_align = phy & ~0xFFF
        align_offset = phy - offset_align
        size = 0x100 + align_offset
        mem_mapped = mmap.mmap(mem.fileno(), size, offset=offset_align)
        #### clock
        data = 100
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[0x70 + align_offset : 0x70 + align_offset + len(data_b)] = data_b
        #####w and h
        data = ((w << 16) & 0xFFFF0000) | (h & 0x0000FFFF)
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[0x8 + align_offset : 0x8 + align_offset + len(data_b)] = data_b
        #### stride
        data = w * 4
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[0x14 + align_offset : 0x14 + align_offset + len(data_b)] = data_b
        #### buffer addresee
        data = buffer_addr
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[0x10 + align_offset : 0x10 + align_offset + len(data_b)] = data_b
        ### start 
        data = 0x50011
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[0x4 + align_offset : 0x4 + align_offset + len(data_b)] = data_b
        #data_bytes = mem_mapped.read(size)
        #data = np.frombuffer(data_bytes, dtype=np.uint8).reshape((h,w,4))
        mem_mapped.close()
        return

args = parse_args()
if args.address and args.width and args.height and args.buffer:
    phy = int(args.address, 16)
    buffer_addr = int(args.buffer, 16)
    width = int(args.width)
    height = int(args.height)
    map_phy_addr(phy, buffer_addr, width, height)
else:
    print('dsadsa')
    args.parser.print_help()
