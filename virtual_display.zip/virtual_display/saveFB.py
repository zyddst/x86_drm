import mmap
import numpy as np
from PIL import Image
import argparse
import time

def parse_args():
    parser = argparse.ArgumentParser(description='virtual dispaly tool')
    #parser.add_argument('case', type=str, help='Case to run')
    parser.add_argument('-B', '--address', type=str, help='buffer address')
    parser.add_argument('-W', '--width', type=str, help='width')
    parser.add_argument('-H', '--height', type=str, help='height')
    parser.add_argument('-raw', action="store_true", default=False, help='Enable the raw data dump')
    parser.add_argument('-P', '--path', type=str, help='file path')
    args = parser.parse_args()
    args.parser = parser
    return args

def map_phy_addr(phy, w, h, raw):
    with open('/dev/mem', 'r+b') as mem:
        offset = phy
        bpp = 4
        if raw:
            bpp = 6
            size = w*h*6
        else:
            size = w*h*4
        print(size)
        mem_mapped = mmap.mmap(mem.fileno(), size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE, offset=offset)
        data_bytes = mem_mapped.read(size)
        print(len(data_bytes))
        if raw:
            data = np.frombuffer(data_bytes, dtype=np.uint16).reshape((h,w,3))
        else:
            data = np.frombuffer(data_bytes, dtype=np.uint8).reshape((h,w,bpp))
        mem_mapped.close()
        return data

def clear_buffer(phy, w, h):
    with open('/dev/mem', 'r+b') as mem:
        offset = phy
        size = w*h*4
        mem_mapped = mmap.mmap(mem.fileno(), size, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE, offset=offset)
        zeros = bytearray(size)
        mem_mapped.write(zeros)
        mem_mapped.close()

def save_data_as_bmp(data, file_name,w,h):
    image = Image.fromarray(data, 'RGBA')
    r,g,b,a = image.split()
    image = Image.merge('RGBA', (b,g,r,a))
    #image.fromarray(data, 'RGBA')
    image.save(file_name, 'BMP')

def save_data_as_raw(data, file_name,w,h):
    extracted_data = (data >> 8).astype(np.uint8)

    con_data = extracted_data[..., ::-1]
    con_data.tofile(file_name)

args = parse_args()
if args.address and args.width and args.height and args.path:
    phy = int(args.address, 16)
    width = int(args.width)
    height = int(args.height)
    #clear_buffer(phy, width, height)
    #time.sleep(2)
    data = map_phy_addr(phy, width, height, args.raw)
    if args.raw:
        save_data_as_raw(data, args.path, width, height)
    else:
        save_data_as_bmp(data, args.path, width, height)
    clear_buffer(phy, width, height)
else:
    print('dsadsa')
    args.parser.print_help()
#phy = int(input("please input phy address:"), 16)
#width = int(input("Please input width:"))
#height = int(input("Please input height:"))


