#!/usr/bin/env ruby

require 'fileutils'

begin
  puts <<USAGE_DOCUMENT
Usage: virtual_display.rb [idx=<idx>] [pic_on|pic_off|pic_sel|tpg_on|tpg_off|tpg_sel|view_only|fps|tpg_pattern=<tpg_pattern>|pin_mux_sel=<pin_mux_sel>] [clock_denominator=<clock_denominator>] [pic_crop_x=<pic_crop_x>] [pic_crop_y=<pic_crop_y>] [pic_start_x=<pic_start_x>] [pic_start_y=<pic_start_y>] [pic_width=<pic_width>] [pic_height=<pic_height>]

Working_Scheme:
       
       HostLinux.DisplayFrameBuffer(/dev/fb0) <=====(pic_on/pic_off)=====[Vitrual_display[0]]<====(pic_sel)====[DC[0](i.e. DC8000 instance 0)]
                                        A                                       A
                                        H                                       H
                                    (if /dev/fb1 is not available)          (tpg_sel)<====(tpg_on/tpg_off)====[TPG[0]]
                                                           A
                                                           H
       HostLinux.DisplayFrameBuffer(/dev/fb1) <=====(pic_on/pic_off)=====[Vitrual_display[1]]<====(pic_sel)====[DC[1](i.e. DC8000 instance 1)]
                                                                                A
                                                                                H
                                                                            (tpg_sel)<====(tpg_on/tpg_off)====[TPG[1]]
                                                                             
Note : 1. Any option of { pic_on, pic_off, pic_sel, tpg_on, tpg_off, tpg_sel, view_only, tpg_pattern, pin_mux_sel } can only be used solely.
          Never use it the with other options together.
          Following are the valid usages of them. (Note: if idx=1, then the setting will be applied to virtual_display[1] instead)
            virtual_display.rb idx=0 pic_on
            virtual_display.rb idx=0 pic_off
            virtual_display.rb idx=0 pic_sel
            virtual_display.rb idx=0 tpg_on
            virtual_display.rb idx=0 tpg_off
            virtual_display.rb idx=0 tpg_sel
            virtual_display.rb idx=0 view_only
            virtual_display.rb idx=0 fps
            virtual_display.rb idx=0 tpg_pattern=<32bit_value>
            virtual_display.rb idx=0 pin_mux_sel=<pin_mux_sel>
            The <tpg_pattern> is a 32-bit value.  ; Default value = 0x01484848
            The <pin_mux_sel> = following names   ; Default value = RGB888
                                D16CFG1
                                D16CFG2
                                D16CFG3
                                D18CFG1
                                D18CFG2
                                D24
                                D30
                                RGB565
                                RGB666
                                RGB888
                                RGB101010
                                DPRGB101010
                          
       2. Details of other options:
          <pic_crop_x>  = Need to be a value that can be divided by 4  ; Default value = 0
          <pic_crop_y>  =                                              ; Default value = 0
          <pic_start_x> = Need to be a value that can be divided by 4  ; Default value = 0
          <pic_start_y> =                                              ; Default value = 0
          <pic_width>   = Need to be a value that can be divided by 4  ; Default value = 1920
          <pic_height>  =                                              ; Default value = 1080
          <idx>         = virtual_display ID. Value can be 0 or 1      ; Default value = 0
          <clock_denominator> is used to control the frequency of pixel clock  ; Default value = 4
            The Freq(pixel_clock) = (200.0/<clock_denominator>) MHz
          
       3. fps : Report the current video output status.

USAGE_DOCUMENT
  exit
end unless ARGV.length >= 1

################################################################################
class Fixnum

  alias :old_bit_method :[]

  def [](*args)
    if(args.empty?)
      self
    else
      tmp_val = 0
      args.each do |obj|
        if(obj.is_a? Range)
          nobj = (obj.min)? (obj.last..obj.first): obj
          num_of_bits = (nobj.first-nobj.last+1)
          tmp_val = (tmp_val<<num_of_bits) | ((self>>nobj.last)&((1<<num_of_bits)-1))
        else
          tmp_val = (tmp_val<<1) | self.old_bit_method(obj)
        end
      end
      tmp_val
    end
  end

end

################################################################################
require 'fileutils'
require '/root/sdk/S2C/bin/develop/gems/mmio/lib/mmio'
include MemoryMappedIO


require 'bindata'

class BMP_header < BinData::Record
  endian :little
  string :file_type, :read_length => 2
  uint32 :file_size
  uint16 :reserved_field1
  uint16 :reserved_field2
  uint32 :offset_to_pic_data
  uint32 :header_size
  uint32 :pic_width
  uint32 :pic_height
  uint16 :num_of_color_planes
  uint16 :bits_per_pixel
  uint32 :compression_method
  uint32 :pic_size
  uint32 :x_resolution
  uint32 :y_resolution
  uint32 :colors_in_palette
  uint32 :num_of_important_colors_used
  string :extra_info, :read_length => 84
end

######  io = File.open("test_frame.bmp")
######  r  = BMP_header.read(io)
######  puts "
######  puts "file_type                     = %02s"   % [ r.file_type                   ]
######  puts "file_size                     = 0x%04x" % [ r.file_size                   ]
######  puts "reserved_field1               = 0x%02x" % [ r.reserved_field1             ]
######  puts "reserved_field2               = 0x%02x" % [ r.reserved_field2             ]
######  puts "offset_to_pic_data            = 0x%04x" % [ r.offset_to_pic_data          ]
######  puts "header_size                   = 0x%04x" % [ r.header_size                 ]
######  puts "pic_width                     = 0x%04x" % [ r.pic_width                   ]
######  puts "pic_height                    = 0x%04x" % [ r.pic_height                  ]
######  puts "num_of_color_planes           = 0x%02x" % [ r.num_of_color_planes         ]
######  puts "bits_per_pixel                = 0x%02x" % [ r.bits_per_pixel              ]
######  puts "compression_method            = 0x%04x" % [ r.compression_method          ]
######  puts "pic_size                      = 0x%04x" % [ r.pic_size                    ]
######  puts "x_resolution                  = 0x%04x" % [ r.x_resolution                ]
######  puts "y_resolution                  = 0x%04x" % [ r.y_resolution                ]
######  puts "colors_in_palette             = 0x%04x" % [ r.colors_in_palette           ]
######  puts "num_of_important_colors_used  = 0x%04x" % [ r.num_of_important_colors_used]

$bmp_header_string = [ 0x42, 0x4D, 0x8A, 0xEC, 0x5E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x8A, 0x00, 0x00, 0x00, 0x7C, 0x00,
                       0x00, 0x00, 0x80, 0x07, 0x00, 0x00, 0x38, 0x04, 0x00, 0x00, 0x01, 0x00, 0x18, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0xEC, 0x5E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0xFF, 0x00, 0x00, 0xFF, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x42, 0x47, 0x52, 0x73, 0x80, 0xC2, 0xF5, 0x28, 0x60, 0xB8,
                       0x1E, 0x15, 0x20, 0x85, 0xEB, 0x01, 0x40, 0x33, 0x33, 0x13, 0x80, 0x66, 0x66, 0x26, 0x40, 0x66,
                       0x66, 0x06, 0xA0, 0x99, 0x99, 0x09, 0x3C, 0x0A, 0xD7, 0x03, 0x24, 0x5C, 0x8F, 0x32, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 ].pack("C*")

def bmp_header(pic_width, pic_height)
  tmp_header = BMP_header.read($bmp_header_string)
  tmp_header.pic_width  = pic_width
  tmp_header.pic_height = pic_height
  line_buffer_size = pic_width*3
  line_buffer_size += (4-(line_buffer_size%4)) if(line_buffer_size%4 != 0)
  tmp_header.pic_size  = line_buffer_size*pic_height
  tmp_header.file_size = line_buffer_size*pic_height + $bmp_header_string.size
  tmp_header.to_binary_s
end

def rgb_to_bmp( pic_width, pic_height, rgb_matrix, bmp_filename)
  puts "(#{Time.now}) INFO: Start of saving the RGB data into BMP data into %s ." % [ bmp_filename]
  bmp_header_string = bmp_header(pic_width, pic_height)
  bmp_pixels_string = rgb_matrix.flatten.pack("C*")

  IO.binwrite( bmp_filename, bmp_header_string)
  IO.binwrite( bmp_filename, bmp_pixels_string, bmp_header_string.size)
  puts "(#{Time.now}) INFO: End of saving the RGB data into BMP data into %s ." % [ bmp_filename]
end

def fb_to_rgb_matrix( fb_idx, pic_width, pic_height, bpp=32)
  puts "(#{Time.now}) INFO: Start of saving the FrameBuffer(#{fb_idx})'s RGB data into rgb_matrix."
  fbs = File.open("/dev/fb#{fb_idx}","r")
  rgb_matrix = []
  bytes_per_pixel = bpp/8
  bytes_per_line = pic_width*bytes_per_pixel

  (0...pic_height).each do |row_idx|
    tmp = fbs.read(bytes_per_line)
    if(bpp == 32)
      (0...bytes_per_line).step(bytes_per_pixel) do |ptr|
      	rgb_matrix << [ tmp[ptr], tmp[ptr+1], tmp[ptr+2]]
      end
    else
      (0...bytes_per_line).step(bytes_per_pixel) do |ptr|
      	pixel_data = tmp[ptr+1].ord<<8 | tmp[ptr].ord
      	rgb_matrix << [ (pixel_data&0x1f)<<3, (pixel_data&0x7e0)>>3, (pixel_data&0xf8)>>8]
      end
    end
  end

  fbs.close
  puts "(#{Time.now}) INFO: End of saving the FrameBuffer(#{fb_idx})'s RGB data into rgb_matrix."
  rgb_matrix
end

def get_base_address_for_fb( fb_idx)
  iomem_info = `cat /proc/iomem | grep 0000:00:02.0`.split(/\s*\n+\s*/)
  search_base = 0
  if(iomem_info[0] =~ /^\s*([0-9a-fA-F]+)/)
  	search_base = $1.to_i(16)
  end
  if(search_base == 0)
  	return(nil)
  end
  fbs = File.open("/dev/fb#{fb_idx}","wb")
  fbs.write([0x12, 0x34, 0x56, 0x78].reverse.pack("C*"))
  fbs.close
  ptr = search_base
  mark_found = false
  dwords_checked = 0
  until(mark_found || dwords_checked >= 0x1000000)
  	if(mread( ptr, "w" ) == 0x12345678)
  	  mark_found = true
  	  break
    end
  	ptr += 4
  	dwords_checked += 1
  end
  (mark_found)? ptr: search_base
end

################################################################################

################################################################################
def time_of(sec)
  min, second = sec.divmod(60)
  hrs, minute = min.divmod(60)
  day, hour   = hrs.divmod(24)
  ((day == 0)? "": "#{day} day%s"%((day>1)? "s":"")) +
  ((hour == 0)? "": "#{hour} hour%s"%((hour>1)? "s":"")) +
  ((minute == 0)? "": "#{minute} minute%s"%((minute>1)? "s":"")) +
  "#{second} second%s"%((second>1)? "s":"")
end

################################################################################
def movement_in( x_grid, y_grid, delta_x=1, delta_y=1, num_of_steps=0)
  ptr_x, ptr_y = 0, 0
  idx_of_step = 0
  while(num_of_steps == 0 || idx_of_step < num_of_steps)
  	yield x_grid[ptr_x], y_grid[ptr_y]

    ptr_x += delta_x
    if(ptr_x >= x_grid.size)
      ptr_x = x_grid.size - 1
      delta_x = -delta_x
    elsif(ptr_x < 0)
      ptr_x = 0
      delta_x = -delta_x
    end

    ptr_y += delta_y
    if(ptr_y >= y_grid.size)
      ptr_y = y_grid.size - 1
      delta_y = -delta_y
    elsif(ptr_y < 0)
      ptr_y = 0
      delta_y = -delta_y
    end

  	idx_of_step += 1
  end
end

def get_base_address
  tmp = `lspci -v`.split(/\s*\n\s*/).select{ |x| x=~/Co-processor: Xilinx|Memory at/}
  tmp[tmp.index{ |x| x=~/Co-processor/}+1..-1].map { |x| x=~/Memory at (\S+)/; $1.to_i(16)}
end

######
pin_mux_id = {
               :D16CFG1   => 0   ,
               :D16CFG2   => 1   ,
               :D16CFG3   => 2   ,
               :D18CFG1   => 3   ,
               :D18CFG2   => 4   ,
               :D24       => 5   ,
               :D30       => 6   ,
               :RGB565    => 8+0 ,
               :RGB666    => 8+1 ,
               :RGB888    => 8+2 ,
               :RGB101010 => 8+3 ,
               :DPRGB101010 => 8+4
	         }

vdp_idx = 0
pin_mux_sel = :RGB888
clock_denominator = 4
pic_crop_x = 0
pic_crop_y = 0
pic_start_x = 0
pic_start_y = 0
pic_width   = 1920
pic_height  = 1080
debug  = false
pic_on = false
tpg_on = false
tpg_sel= false
view_only = false
fps_report = false
tpg_pattern = 0x01484848

pin_mux_sel_only = false
pic_switch_only = false
tpg_switch_only = false
src_select_only = false
tpg_pattern_only = false
clock_denominator_only = false
######

ARGV.delete_if do |item|
  checker_says = true
  case item.delete(' ')
    when /clock_denominator\s*=\s*(\S+)/i      then clock_denominator = eval($1); clock_denominator_only = true
    when /pic_crop_x\s*=\s*(\S+)/i       then pic_crop_x  = eval($1)
    when /pic_crop_y\s*=\s*(\S+)/i       then pic_crop_y  = eval($1)
    when /pic_start_x\s*=\s*(\S+)/i      then pic_start_x = eval($1)
    when /pic_start_y\s*=\s*(\S+)/i      then pic_start_y = eval($1)
    when /pic_width\s*=\s*(\S+)/i        then pic_width   = eval($1)
    when /pic_height\s*=\s*(\S+)/i       then pic_height  = eval($1)
    when /pin_mux_sel\s*=\s*(\S+)/i      then 
      if(pin_mux_id[$1.to_sym])
        pin_mux_sel = $1.to_sym
        if(ARGV.size <= 2)
          pin_mux_sel_only = true
        end
      end
    when /^\s*idx\s*=\s*(\S+)/i          then vdp_idx  = eval($1)
    when /swap_in\s*=\s*(\S+)/i          then swap_in  = eval($1)
    when /swap_out\s*=\s*(\S+)/i         then swap_out = eval($1)
    when /pic_(on|off)/i                 then pic_on  = ($1.downcase == "on" )? true: false; pic_switch_only = true
    when /tpg_(on|off)/i                 then tpg_on  = ($1.downcase == "on" )? true: false; tpg_switch_only = true
    when /(pic|tpg)_sel/i                then tpg_sel = ($1.downcase == "tpg")? true: false; src_select_only = true
    when /view/i                         then view_only = true
    when /fps/i                          then fps_report = true
    when /tpg_pattern\s*=\s*(\S+)/i      then tpg_pattern = eval($1); tpg_pattern_only = true
    when /^debug$/i                      then debug = true
    else
      checker_says = false
  end
  checker_says
end

vdp_id = [ vdp_idx]
# Dir["/dev/fb*"].map{|x| x[-1].to_i}

#vdp_idx = vdp_id[0]

################################################################################

#pcie_BAR = get_base_address
#
#dc_reg_base  = [ pcie_BAR[1], pcie_BAR[1]|(1<<20) ]
#vdp_reg_base = [ pcie_BAR[0], pcie_BAR[0]|(1<<8)  ]
#
#dc_reg_base  = [ eval(ENV["dc_regbase"]),  eval(ENV["dc_regbase"])  | (1<<20) ] if ENV["dc_regbase" ]      # 0xf000_0000
vdp_reg_base = [ eval(ENV["vdp_regbase"]), eval(ENV["vdp_regbase"]) | (1<<8)  ] if ENV["vdp_regbase"]      # 0xf100_0000
#puts "DEBUG: vdp_reg_base[0] = 0x%08x, vdp_reg_base[1] = 0x%08x " % [ vdp_reg_base[0], vdp_reg_base[1]]
#print "line357 debug0:0x%08x "  % mread(0xdf800000 , 'w')

######
monitor = [
            { :width=>1920, :height=>1080, :fb_base_addr=>0, :fb_stride=>1920*4, :bpp=>32, :pixel_format=>:rgba8880},
            { :width=>1920, :height=>1080, :fb_base_addr=>0, :fb_stride=>1920*4, :bpp=>32, :pixel_format=>:rgba8880}
          ]

[0,1].each do |idx|
  fb_ptr = idx
  fb_ptr = 0 unless(File.exist?("/dev/fb#{idx}"))
  cmd = "fbset -fb /dev/fb#{fb_ptr} -i"
#  puts "DEBUG: cmd = %s" % [ cmd]
#  puts `#{cmd}`
  monitor[idx][:fb_base_addr] = 0
  `#{cmd}`.split(/\n+/).each do |inline|
    inline.chomp!
    if(inline =~ /geometry\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/)
      monitor[idx][:width], monitor[idx][:height], monitor[idx][:bpp] = $1.to_i, $2.to_i, $5.to_i
    elsif(inline =~ /LineLength\s*:\s*(\S+)/)
      monitor[idx][:fb_stride] = eval($1)
    elsif(inline =~ /Address\s*:\s*(\S+)/)
#      puts "DEBUG: Address = %s" % [ $1]
      monitor[idx][:fb_base_addr] = eval($1)
    elsif(inline =~ /^\s*(\w+)\s+(\S+)/)
      fmt, layout = $1, $2
      if(layout["/"])
      	fmt += layout.split(/\s*,\s*/).map{|x| x=~/\//; $`}.join("")
      	monitor[idx][:pixel_format] = fmt.to_sym
      end
    end
  end
  
  if(monitor[idx][:fb_base_addr] == 0)
  	result = get_base_address_for_fb( fb_ptr)
  	if(result)
  	  monitor[idx][:fb_base_addr] = result
  	else
  	  puts "(#{Time.now}) ERROR: Cannot find the base address for /dev/fb#{fb_ptr} !"
  	  exit
    end
  end
end

######
vdp_reg = [ {}, {}]
vdp_reg_view = [ {}, {}]


if(fps_report)
  vdp_id.each do |idx|
    vdp_reg_view[idx][:video__ctrl      ] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg_view[idx][:video__on        ] = (vdp_reg_view[idx][:video__ctrl][0] == 1)? true: false
    vdp_reg_view[idx][:video__tpg_sel   ] = (vdp_reg_view[idx][:video__ctrl][20] == 1)? true: false
    vdp_reg_view[idx][:video__width     ] = mread( vdp_reg_base[idx] + 0x08, "w" )>>16
    vdp_reg_view[idx][:video__height    ] = mread( vdp_reg_base[idx] + 0x08, "w" )&0xffff
    vdp_reg_view[idx][:clock_denominator] = mread( vdp_reg_base[idx] + 0x70, "w" )
    vdp_reg_view[idx][:pixel_clock      ] = 200.0/vdp_reg_view[idx][:clock_denominator]
    vdp_reg_view[idx][:frm_count        ] = mread( vdp_reg_base[idx] + 0x18, "w" )
    sleep(3)
    vdp_reg_view[idx][:frm_count_3secs  ] = mread( vdp_reg_base[idx] + 0x18, "w" )
    vdp_reg_view[idx][:frm_rate] = vdp_reg_view[idx][:frm_count_3secs] - vdp_reg_view[idx][:frm_count]
    vdp_reg_view[idx][:frm_rate] += 0x100000000 if(vdp_reg_view[idx][:frm_rate] < 0)
    vdp_reg_view[idx][:frm_rate] /= 3.0
    
    if(vdp_reg_view[idx][:video__on])
      puts "INFO(#{Time.now}): Current video[#{idx}] is ACTIVE output from %s with [%d x %d] @ %3.2f fps on pixel_clock=%3.2f MHz" % [ (vdp_reg_view[idx][:video__tpg_sel]? "TPG": "DC8000"), 
                                                                                                     vdp_reg_view[idx][:video__width], vdp_reg_view[idx][:video__height],
                                                                                                     vdp_reg_view[idx][:frm_rate], vdp_reg_view[idx][:pixel_clock]]
    else
      puts "INFO(#{Time.now}): Current video[#{idx}] is OFF"
    end
  end
  exit
end

if(pin_mux_sel_only)
  vdp_id.each do |idx|
    vdp_reg[idx][:video__ctrl] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg[idx][:video__intf] = pin_mux_id.invert[vdp_reg[idx][:video__ctrl][19..16]]
    puts "vdp_reg_view[#{idx}][:video__ctrl] = 0x%08x" % [ vdp_reg[idx][:video__ctrl]]
    puts "vdp_reg_view[#{idx}][:video__intf] = %s"     % [ vdp_reg[idx][:video__intf]]
    vdp_reg[idx][:video__ctrl] = (vdp_reg[idx][:video__ctrl] & (~(0xf<<16))) | ((pin_mux_id[pin_mux_sel])<<16)
    mwrite( vdp_reg_base[idx] + 0x04, "w", vdp_reg[idx][:video__ctrl] )
    vdp_reg[idx][:video__ctrl] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg[idx][:video__intf] = pin_mux_id.invert[vdp_reg[idx][:video__ctrl][19..16]]
    puts "vdp_reg_view[#{idx}][:video__ctrl] = 0x%08x" % [ vdp_reg[idx][:video__ctrl]]
    puts "vdp_reg_view[#{idx}][:video__intf] = %s"     % [ vdp_reg[idx][:video__intf]]
  end
  exit
end

if(pic_switch_only)
  vdp_id.each do |idx|
    vdp_reg[idx][:video__ctrl] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg[idx][:video__on] = (vdp_reg[idx][:video__ctrl][0] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:video__ctrl] = 0x%08x" % [ vdp_reg[idx][:video__ctrl]]
    puts "vdp_reg_view[#{idx}][:video__on  ] = %s"     % [ vdp_reg[idx][:video__on  ]]
    vdp_reg[idx][:video__ctrl] = (vdp_reg[idx][:video__ctrl] & (~1)) | ((pic_on)?1:0)
    mwrite( vdp_reg_base[idx] + 0x04, "w", vdp_reg[idx][:video__ctrl] )
    vdp_reg[idx][:video__ctrl] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg[idx][:video__on] = (vdp_reg[idx][:video__ctrl][0] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:video__ctrl] = 0x%08x" % [ vdp_reg[idx][:video__ctrl]]
    puts "vdp_reg_view[#{idx}][:video__on  ] = %s"     % [ vdp_reg[idx][:video__on  ]]
  end
  exit
end

if(src_select_only)
  vdp_id.each do |idx|
    vdp_reg[idx][:video__ctrl] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg[idx][:video__tpg_sel] = (vdp_reg[idx][:video__ctrl][20] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:video__ctrl   ] = 0x%08x" % [ vdp_reg[idx][:video__ctrl   ]]
    puts "vdp_reg_view[#{idx}][:video__tpg_sel] = %s"     % [ vdp_reg[idx][:video__tpg_sel]]
    vdp_reg[idx][:video__ctrl] = (vdp_reg[idx][:video__ctrl] & (~(1<<20))) | ((tpg_sel)?(1<<20):0)
    mwrite( vdp_reg_base[idx] + 0x04, "w", vdp_reg[idx][:video__ctrl] )
    vdp_reg[idx][:video__ctrl] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg[idx][:video__tpg_sel] = (vdp_reg[idx][:video__ctrl][20] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:video__ctrl   ] = 0x%08x" % [ vdp_reg[idx][:video__ctrl   ]]
    puts "vdp_reg_view[#{idx}][:video__tpg_sel] = %s"     % [ vdp_reg[idx][:video__tpg_sel]]
  end
  exit
end

if(tpg_switch_only)
  vdp_id.each do |idx|
    vdp_reg[idx][:tpg__ctrl] = mread( vdp_reg_base[idx] + 0x60, "w" )
    vdp_reg[idx][:tpg__on] = (vdp_reg[idx][:tpg__ctrl][28] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:tpg__ctrl] = 0x%08x" % [ vdp_reg[idx][:tpg__ctrl]]
    puts "vdp_reg_view[#{idx}][:tpg__on  ] = %s"     % [ vdp_reg[idx][:tpg__on  ]]
    vdp_reg[idx][:tpg__ctrl] = (vdp_reg[idx][:tpg__ctrl] & (~(1<<28))) | ((tpg_on)?(1<<28):0)
    mwrite( vdp_reg_base[idx] + 0x60, "w", vdp_reg[idx][:tpg__ctrl] )
    vdp_reg[idx][:tpg__ctrl] = mread( vdp_reg_base[idx] + 0x60, "w" )
    vdp_reg[idx][:tpg__on] = (vdp_reg[idx][:tpg__ctrl][28] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:tpg__ctrl] = 0x%08x" % [ vdp_reg[idx][:tpg__ctrl]]
    puts "vdp_reg_view[#{idx}][:tpg__on  ] = %s"     % [ vdp_reg[idx][:tpg__on  ]]
  end
  exit
end

if(tpg_pattern_only)
  vdp_id.each do |idx|
    vdp_reg[idx][:tpg__ctrl] = mread( vdp_reg_base[idx] + 0x60, "w" )
    vdp_reg[idx][:tpg__on] = (vdp_reg[idx][:tpg__ctrl][28] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:tpg__ctrl] = 0x%08x" % [ vdp_reg[idx][:tpg__ctrl]]
    puts "vdp_reg_view[#{idx}][:tpg__on  ] = %s"     % [ vdp_reg[idx][:tpg__on  ]]
    vdp_reg[idx][:tpg__ctrl] = (vdp_reg[idx][:tpg__ctrl] & ~((1<<27)-1)) | (tpg_pattern & ((1<<27)-1))
    mwrite( vdp_reg_base[idx] + 0x60, "w", vdp_reg[idx][:tpg__ctrl] )
    vdp_reg[idx][:tpg__ctrl] = mread( vdp_reg_base[idx] + 0x60, "w" )
    vdp_reg[idx][:tpg__on] = (vdp_reg[idx][:tpg__ctrl][28] == 1)? true: false
    puts "vdp_reg_view[#{idx}][:tpg__ctrl] = 0x%08x" % [ vdp_reg[idx][:tpg__ctrl]]
    puts "vdp_reg_view[#{idx}][:tpg__on  ] = %s"     % [ vdp_reg[idx][:tpg__on  ]]
  end
  exit
end

if(clock_denominator_only)
  vdp_id.each do |idx|
    vdp_reg[idx][:clock_denominator] = mread( vdp_reg_base[idx] + 0x70, "w" )
    puts "vdp_reg_view[#{idx}][:clock_denominator] = 0x%08x" % [ vdp_reg[idx][:clock_denominator]]
    vdp_reg[idx][:clock_denominator] = clock_denominator
    mwrite( vdp_reg_base[idx] + 0x70, "w", vdp_reg[idx][:clock_denominator] )
    vdp_reg[idx][:clock_denominator] = mread( vdp_reg_base[idx] + 0x70, "w" )
    puts "vdp_reg_view[#{idx}][:clock_denominator] = 0x%08x" % [ vdp_reg[idx][:clock_denominator]]
  end
  exit
end

######
[0,1].each do |idx|
  puts "(#{Time.now}) INFO: Read Monitor_FB[%d] output geometry{ width, height, bpp/pixel_format } = { %d, %d, %d/%s}" % [ idx, monitor[idx][:width], monitor[idx][:height], monitor[idx][:bpp], monitor[idx][:pixel_format]]
  puts "(#{Time.now}) INFO: Read Monitor_FB[%d] output mem_info{ fb_base_addr, fb_stride } = { 0x%08x, %d }" % [ idx, monitor[idx][:fb_base_addr], monitor[idx][:fb_stride]]
end


######

if(view_only)
  vdp_id.each do |idx|
    vdp_reg_view[idx][:video__ctrl     ] = mread( vdp_reg_base[idx] + 0x04, "w" )
    vdp_reg_view[idx][:video__on       ] = (vdp_reg_view[idx][:video__ctrl][0] == 1)? true: false
    vdp_reg_view[idx][:video__format   ] = (vdp_reg_view[idx][:video__ctrl][5..4][0] == 0)? :rgba5650 : :rgba8880
    vdp_reg_view[idx][:video__intf     ] = pin_mux_id.invert[vdp_reg_view[idx][:video__ctrl][19..16]]
    vdp_reg_view[idx][:video__tpg_sel  ] = (vdp_reg_view[idx][:video__ctrl][20] == 1)? true: false

    vdp_reg_view[idx][:video__width    ] = mread( vdp_reg_base[idx] + 0x08, "w" )>>16
    vdp_reg_view[idx][:video__height   ] = mread( vdp_reg_base[idx] + 0x08, "w" )&0xffff
    vdp_reg_view[idx][:crop__X         ] = mread( vdp_reg_base[idx] + 0x0c, "w" )>>16
    vdp_reg_view[idx][:crop__Y         ] = mread( vdp_reg_base[idx] + 0x0c, "w" )&0xffff
    vdp_reg_view[idx][:fb_base_addr    ] = mread( vdp_reg_base[idx] + 0x10, "w" )
    vdp_reg_view[idx][:fb_stride       ] = mread( vdp_reg_base[idx] + 0x14, "w" )
    vdp_reg_view[idx][:start__X        ] = ((vdp_reg_view[idx][:fb_base_addr] - monitor[idx][:fb_base_addr]) % monitor[idx][:fb_stride]) / (monitor[idx][:bpp]/8)
    vdp_reg_view[idx][:start__Y        ] = ((vdp_reg_view[idx][:fb_base_addr] - monitor[idx][:fb_base_addr]) / monitor[idx][:fb_stride]) 

    vdp_reg_view[idx][:frm_count       ] = mread( vdp_reg_base[idx] + 0x18, "w" )
    vdp_reg_view[idx][:row_count       ] = mread( vdp_reg_base[idx] + 0x1c, "w" )>>16
    vdp_reg_view[idx][:col_count       ] = mread( vdp_reg_base[idx] + 0x1c, "w" )&0xffff
    vdp_reg_view[idx][:DECERR_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>24)&0xff
    vdp_reg_view[idx][:SLVERR_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>16)&0xff
    vdp_reg_view[idx][:EXOKAY_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>8 )&0xff

    vdp_reg_view[idx][:axi_rd_req_cnt  ] = mread( vdp_reg_base[idx] + 0x30, "w" )
    vdp_reg_view[idx][:axi_rd_data_cnt ] = mread( vdp_reg_base[idx] + 0x34, "w" )
    vdp_reg_view[idx][:axi_rd_resp_cnt ] = mread( vdp_reg_base[idx] + 0x38, "w" )
    vdp_reg_view[idx][:axi_wr_req_cnt  ] = mread( vdp_reg_base[idx] + 0x40, "w" )
    vdp_reg_view[idx][:axi_wr_data_cnt ] = mread( vdp_reg_base[idx] + 0x44, "w" )
    vdp_reg_view[idx][:axi_wr_resp_cnt ] = mread( vdp_reg_base[idx] + 0x48, "w" )
    vdp_reg_view[idx][:axi_wr_bresp_cnt] = mread( vdp_reg_base[idx] + 0x4c, "w" )

    vdp_reg_view[idx][:tpg__ctrl       ] = mread( vdp_reg_base[idx] + 0x60, "w" )
    vdp_reg_view[idx][:tpg__on         ] = (vdp_reg_view[idx][:tpg__ctrl][28] == 1)? true: false
    vdp_reg_view[idx][:tpg__width      ] = mread( vdp_reg_base[idx] + 0x64, "w" )>>16
    vdp_reg_view[idx][:tpg__height     ] = mread( vdp_reg_base[idx] + 0x64, "w" )&0xffff

    vdp_reg_view[idx][:clock_denominator]= mread( vdp_reg_base[idx] + 0x70, "w" )

    puts "vdp_reg_view[#{idx}][:video__ctrl     ] = 0x%08x" % [ vdp_reg_view[idx][:video__ctrl     ]]
    puts "vdp_reg_view[#{idx}][:video__on       ] = %s"     % [ vdp_reg_view[idx][:video__on       ]]
    puts "vdp_reg_view[#{idx}][:video__format   ] = %s"     % [ vdp_reg_view[idx][:video__format   ]]
    puts "vdp_reg_view[#{idx}][:video__intf     ] = %s"     % [ vdp_reg_view[idx][:video__intf     ]]
    puts "vdp_reg_view[#{idx}][:video__tpg_sel  ] = %s"     % [ vdp_reg_view[idx][:video__tpg_sel  ]]

    puts "vdp_reg_view[#{idx}][:video__width    ] = %d"     % [ vdp_reg_view[idx][:video__width    ]]
    puts "vdp_reg_view[#{idx}][:video__height   ] = %d"     % [ vdp_reg_view[idx][:video__height   ]]
    puts "vdp_reg_view[#{idx}][:crop__X         ] = %d"     % [ vdp_reg_view[idx][:crop__X         ]]
    puts "vdp_reg_view[#{idx}][:crop__Y         ] = %d"     % [ vdp_reg_view[idx][:crop__Y         ]]
    puts "vdp_reg_view[#{idx}][:start__X        ] = %d"     % [ vdp_reg_view[idx][:start__X        ]]
    puts "vdp_reg_view[#{idx}][:start__Y        ] = %d"     % [ vdp_reg_view[idx][:start__Y        ]]
    puts "vdp_reg_view[#{idx}][:fb_base_addr    ] = 0x%08x" % [ vdp_reg_view[idx][:fb_base_addr    ]]
    puts "vdp_reg_view[#{idx}][:fb_stride       ] = 0x%08x" % [ vdp_reg_view[idx][:fb_stride       ]]

    puts "vdp_reg_view[#{idx}][:frm_count       ] = %d"     % [ vdp_reg_view[idx][:frm_count       ]]
    puts "vdp_reg_view[#{idx}][:row_count       ] = %d"     % [ vdp_reg_view[idx][:row_count       ]]
    puts "vdp_reg_view[#{idx}][:col_count       ] = %d"     % [ vdp_reg_view[idx][:col_count       ]]
    puts "vdp_reg_view[#{idx}][:DECERR_count    ] = %d"     % [ vdp_reg_view[idx][:DECERR_count    ]]
    puts "vdp_reg_view[#{idx}][:SLVERR_count    ] = %d"     % [ vdp_reg_view[idx][:SLVERR_count    ]]
    puts "vdp_reg_view[#{idx}][:EXOKAY_count    ] = %d"     % [ vdp_reg_view[idx][:EXOKAY_count    ]]

    puts "vdp_reg_view[#{idx}][:axi_rd_req_cnt  ] = %d"     % [ vdp_reg_view[idx][:axi_rd_req_cnt  ]]
    puts "vdp_reg_view[#{idx}][:axi_rd_data_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_rd_data_cnt ]]
    puts "vdp_reg_view[#{idx}][:axi_rd_resp_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_rd_resp_cnt ]]
    puts "vdp_reg_view[#{idx}][:axi_wr_req_cnt  ] = %d"     % [ vdp_reg_view[idx][:axi_wr_req_cnt  ]]
    puts "vdp_reg_view[#{idx}][:axi_wr_data_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_wr_data_cnt ]]
    puts "vdp_reg_view[#{idx}][:axi_wr_resp_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_wr_resp_cnt ]]
    puts "vdp_reg_view[#{idx}][:axi_wr_bresp_cnt] = %d"     % [ vdp_reg_view[idx][:axi_wr_bresp_cnt]]

    puts "vdp_reg_view[#{idx}][:tpg__ctrl       ] = 0x%08x" % [ vdp_reg_view[idx][:tpg__ctrl     ]]
    puts "vdp_reg_view[#{idx}][:tpg__on         ] = %s"     % [ vdp_reg_view[idx][:tpg__on]]
    puts "vdp_reg_view[#{idx}][:tpg__width      ] = %d"     % [ vdp_reg_view[idx][:tpg__width    ]]
    puts "vdp_reg_view[#{idx}][:tpg__height     ] = %d"     % [ vdp_reg_view[idx][:tpg__height   ]]

    puts "vdp_reg_view[#{idx}][:clock_denominator]= %d"     % [ vdp_reg_view[idx][:clock_denominator]]
    puts "vdp_reg_view[#{idx}][:vi_clk] = %3.2f MHz"        % [ (200.0/vdp_reg_view[idx][:clock_denominator])]
  end
  exit
end

######

picture = [
            { :width=>pic_width, :height=>pic_height, :start_x=>pic_start_x, :start_y=>pic_start_y, :crop_x=>pic_crop_x, :crop_y=>pic_crop_y, :pin_mux_sel=>pin_mux_sel, :fb_base_addr=>0, :fb_stride=>1920*4 },
            { :width=>pic_width, :height=>pic_height, :start_x=>pic_start_x, :start_y=>pic_start_y, :crop_x=>pic_crop_x, :crop_y=>pic_crop_y, :pin_mux_sel=>pin_mux_sel, :fb_base_addr=>0, :fb_stride=>1920*4 }
          ]

vdp_id.each do |idx|
  if(picture[idx][:start_x] >= monitor[idx][:width])
  	picture[idx][:start_x] = 0
  end
  if(picture[idx][:start_x]+picture[idx][:width] > monitor[idx][:width])
  	picture[idx][:width] = monitor[idx][:width] - picture[idx][:start_x]
  end
  if(picture[idx][:start_y] >= monitor[idx][:height])
  	picture[idx][:start_y] = 0
  end
  if(picture[idx][:start_y]+picture[idx][:height] > monitor[idx][:height])
  	picture[idx][:height] = monitor[idx][:height] - picture[idx][:start_y]
  end

  picture[idx][:fb_base_addr] = monitor[idx][:fb_base_addr] + (picture[idx][:start_y]*monitor[idx][:fb_stride]) + (picture[idx][:start_x]*monitor[idx][:bpp]/8)
  picture[idx][:fb_stride   ] = monitor[idx][:fb_stride]

  puts "(#{Time.now}) INFO: Read DC[%d] output geometry{ crop_x,   crop_y      } = { %d, %d }" % [ idx, picture[idx][:crop_x], picture[idx][:crop_y]]
  puts "(#{Time.now}) INFO: Read DC[%d] output geometry{ start_x,   start_y    } = { %d, %d }" % [ idx, picture[idx][:start_x], picture[idx][:start_y]]
  puts "(#{Time.now}) INFO: Read DC[%d] output geometry{ pic_width, pic_height } = { %d, %d }" % [ idx, picture[idx][:width], picture[idx][:height]]
  puts "(#{Time.now}) INFO: Read DC[%d] output geometry{ pin_mux_sel           } = { %s }" % [ idx, picture[idx][:pin_mux_sel]]
  puts "(#{Time.now}) INFO: Read DC[%d] output mem_info{ fb_base_addr, fb_stride } = { 0x%08x, %d }" % [ idx, picture[idx][:fb_base_addr], picture[idx][:fb_stride]]
end

######

vdp_id.each do |idx|
  vdp_mark = mread( vdp_reg_base[idx] + 0x00, 'w')
  #puts"DEBUG line646 0x%08x" % [vdp_reg_base[idx]]
  unless(vdp_mark == 0x70dc_8000)
    puts "(#{Time.now}) ERROR: Cannot found the Vitual Display DMA logic. Content of register vdp%d_mark should be 0x70dc_8000. It is 0x%08x now!" % [ idx, vdp_mark]
    exit
  end
end

######


# { video__width, video__height}:
# { crop__X, crop__Y}:
# { start__X, start__Y}:
# fb_base_addr :
# fb_stride    :
# wire         video__on        = video__ctrl[0];
# wire [1:0]   video__format    = video__ctrl[5:4];
# wire [3:0]   video__intf      = video__ctrl[19:16];
# wire         video__tpg_sel   = video__ctrl[20];
#                         (reg_addr == 8'h60)? tpg__ctrl        :
#                         (reg_addr == 8'h64)? { tpg__width, tpg__height}:


vdp_id.each do |idx|
  vdp_reg[idx][:video__ctrl   ] = ((monitor[idx][:bpp] == 32)? 1: 0)<<4 | pin_mux_id[picture[idx][:pin_mux_sel]]<<16
  vdp_reg[idx][:video__width  ] = picture[idx][:width]
  vdp_reg[idx][:video__height ] = picture[idx][:height]
  vdp_reg[idx][:crop__X       ] = picture[idx][:crop_x]
  vdp_reg[idx][:crop__Y       ] = picture[idx][:crop_y]
  vdp_reg[idx][:start__X      ] = picture[idx][:start_x]
  vdp_reg[idx][:start__Y      ] = picture[idx][:start_y]
  vdp_reg[idx][:fb_base_addr  ] = picture[idx][:fb_base_addr]
  vdp_reg[idx][:fb_stride     ] = picture[idx][:fb_stride]
  vdp_reg[idx][:tpg__ctrl     ] = tpg_pattern
  vdp_reg[idx][:tpg__width    ] = monitor[idx][:width]
  vdp_reg[idx][:tpg__height   ] = monitor[idx][:height]
end

vdp_id.each do |idx|
  vdp_reg_view[idx][:video__ctrl     ] = mread( vdp_reg_base[idx] + 0x04, "w" )
  vdp_reg_view[idx][:video__on       ] = (vdp_reg_view[idx][:video__ctrl][0] == 1)? true: false
  vdp_reg_view[idx][:video__format   ] = (vdp_reg_view[idx][:video__ctrl][5..4][0] == 0)? :rgba5650 : :rgba8880
  vdp_reg_view[idx][:video__intf     ] = pin_mux_id.invert[vdp_reg_view[idx][:video__ctrl][19..16]]
  vdp_reg_view[idx][:video__tpg_sel  ] = (vdp_reg_view[idx][:video__ctrl][20] == 1)? true: false

  vdp_reg_view[idx][:video__width    ] = mread( vdp_reg_base[idx] + 0x08, "w" )>>16
  vdp_reg_view[idx][:video__height   ] = mread( vdp_reg_base[idx] + 0x08, "w" )&0xffff
  vdp_reg_view[idx][:crop__X         ] = mread( vdp_reg_base[idx] + 0x0c, "w" )>>16
  vdp_reg_view[idx][:crop__Y         ] = mread( vdp_reg_base[idx] + 0x0c, "w" )&0xffff
  vdp_reg_view[idx][:fb_base_addr    ] = mread( vdp_reg_base[idx] + 0x10, "w" )
  vdp_reg_view[idx][:fb_stride       ] = mread( vdp_reg_base[idx] + 0x14, "w" )
  vdp_reg_view[idx][:start__X        ] = ((vdp_reg_view[idx][:fb_base_addr] - monitor[idx][:fb_base_addr]) % monitor[idx][:fb_stride]) / (monitor[idx][:bpp]/8)
  vdp_reg_view[idx][:start__Y        ] = ((vdp_reg_view[idx][:fb_base_addr] - monitor[idx][:fb_base_addr]) / monitor[idx][:fb_stride]) 

  vdp_reg_view[idx][:frm_count       ] = mread( vdp_reg_base[idx] + 0x18, "w" )
  vdp_reg_view[idx][:row_count       ] = mread( vdp_reg_base[idx] + 0x1c, "w" )>>16
  vdp_reg_view[idx][:col_count       ] = mread( vdp_reg_base[idx] + 0x1c, "w" )&0xffff
  vdp_reg_view[idx][:DECERR_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>24)&0xff
  vdp_reg_view[idx][:SLVERR_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>16)&0xff
  vdp_reg_view[idx][:EXOKAY_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>8 )&0xff

  vdp_reg_view[idx][:axi_rd_req_cnt  ] = mread( vdp_reg_base[idx] + 0x30, "w" )
  vdp_reg_view[idx][:axi_rd_data_cnt ] = mread( vdp_reg_base[idx] + 0x34, "w" )
  vdp_reg_view[idx][:axi_rd_resp_cnt ] = mread( vdp_reg_base[idx] + 0x38, "w" )
  vdp_reg_view[idx][:axi_wr_req_cnt  ] = mread( vdp_reg_base[idx] + 0x40, "w" )
  vdp_reg_view[idx][:axi_wr_data_cnt ] = mread( vdp_reg_base[idx] + 0x44, "w" )
  vdp_reg_view[idx][:axi_wr_resp_cnt ] = mread( vdp_reg_base[idx] + 0x48, "w" )
  vdp_reg_view[idx][:axi_wr_bresp_cnt] = mread( vdp_reg_base[idx] + 0x4c, "w" )

  vdp_reg_view[idx][:tpg__ctrl       ] = mread( vdp_reg_base[idx] + 0x60, "w" )
  vdp_reg_view[idx][:tpg__on         ] = (vdp_reg_view[idx][:tpg__ctrl][28] == 1)? true: false
  vdp_reg_view[idx][:tpg__width      ] = mread( vdp_reg_base[idx] + 0x64, "w" )>>16
  vdp_reg_view[idx][:tpg__height     ] = mread( vdp_reg_base[idx] + 0x64, "w" )&0xffff

  vdp_reg_view[idx][:clock_denominator]= mread( vdp_reg_base[idx] + 0x70, "w" )

  puts "vdp_reg_view[#{idx}][:video__ctrl     ] = 0x%08x" % [ vdp_reg_view[idx][:video__ctrl     ]]
  puts "vdp_reg_view[#{idx}][:video__on       ] = %s"     % [ vdp_reg_view[idx][:video__on       ]]
  puts "vdp_reg_view[#{idx}][:video__format   ] = %s"     % [ vdp_reg_view[idx][:video__format   ]]
  puts "vdp_reg_view[#{idx}][:video__intf     ] = %s"     % [ vdp_reg_view[idx][:video__intf     ]]
  puts "vdp_reg_view[#{idx}][:video__tpg_sel  ] = %s"     % [ vdp_reg_view[idx][:video__tpg_sel  ]]

  puts "vdp_reg_view[#{idx}][:video__width    ] = %d"     % [ vdp_reg_view[idx][:video__width    ]]
  puts "vdp_reg_view[#{idx}][:video__height   ] = %d"     % [ vdp_reg_view[idx][:video__height   ]]
  puts "vdp_reg_view[#{idx}][:crop__X         ] = %d"     % [ vdp_reg_view[idx][:crop__X         ]]
  puts "vdp_reg_view[#{idx}][:crop__Y         ] = %d"     % [ vdp_reg_view[idx][:crop__Y         ]]
  puts "vdp_reg_view[#{idx}][:start__X        ] = %d"     % [ vdp_reg_view[idx][:start__X        ]]
  puts "vdp_reg_view[#{idx}][:start__Y        ] = %d"     % [ vdp_reg_view[idx][:start__Y        ]]
  puts "vdp_reg_view[#{idx}][:fb_base_addr    ] = 0x%08x" % [ vdp_reg_view[idx][:fb_base_addr    ]]
  puts "vdp_reg_view[#{idx}][:fb_stride       ] = 0x%08x" % [ vdp_reg_view[idx][:fb_stride       ]]

  puts "vdp_reg_view[#{idx}][:frm_count       ] = %d"     % [ vdp_reg_view[idx][:frm_count       ]]
  puts "vdp_reg_view[#{idx}][:row_count       ] = %d"     % [ vdp_reg_view[idx][:row_count       ]]
  puts "vdp_reg_view[#{idx}][:col_count       ] = %d"     % [ vdp_reg_view[idx][:col_count       ]]
  puts "vdp_reg_view[#{idx}][:DECERR_count    ] = %d"     % [ vdp_reg_view[idx][:DECERR_count    ]]
  puts "vdp_reg_view[#{idx}][:SLVERR_count    ] = %d"     % [ vdp_reg_view[idx][:SLVERR_count    ]]
  puts "vdp_reg_view[#{idx}][:EXOKAY_count    ] = %d"     % [ vdp_reg_view[idx][:EXOKAY_count    ]]

  puts "vdp_reg_view[#{idx}][:axi_rd_req_cnt  ] = %d"     % [ vdp_reg_view[idx][:axi_rd_req_cnt  ]]
  puts "vdp_reg_view[#{idx}][:axi_rd_data_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_rd_data_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_rd_resp_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_rd_resp_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_req_cnt  ] = %d"     % [ vdp_reg_view[idx][:axi_wr_req_cnt  ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_data_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_wr_data_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_resp_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_wr_resp_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_bresp_cnt] = %d"     % [ vdp_reg_view[idx][:axi_wr_bresp_cnt]]

  puts "vdp_reg_view[#{idx}][:tpg__ctrl       ] = 0x%08x" % [ vdp_reg_view[idx][:tpg__ctrl     ]]
  puts "vdp_reg_view[#{idx}][:tpg__on         ] = %s"     % [ vdp_reg_view[idx][:tpg__on]]
  puts "vdp_reg_view[#{idx}][:tpg__width      ] = %d"     % [ vdp_reg_view[idx][:tpg__width    ]]
  puts "vdp_reg_view[#{idx}][:tpg__height     ] = %d"     % [ vdp_reg_view[idx][:tpg__height   ]]

  puts "vdp_reg_view[#{idx}][:clock_denominator]= %d"     % [ vdp_reg_view[idx][:clock_denominator]]
  puts "vdp_reg_view[#{idx}][:vi_clk] = %3.2f MHz"        % [ (200.0/vdp_reg_view[idx][:clock_denominator])]

end if(debug)

vdp_id.each do |idx|
  mwrite( vdp_reg_base[idx] + 0x04, "w", vdp_reg[idx][:video__ctrl   ] )
  mwrite( vdp_reg_base[idx] + 0x08, "w", vdp_reg[idx][:video__width  ]<<16 | vdp_reg[idx][:video__height ])
  mwrite( vdp_reg_base[idx] + 0x0c, "w", vdp_reg[idx][:crop__X       ]<<16 | vdp_reg[idx][:crop__Y       ])
  mwrite( vdp_reg_base[idx] + 0x10, "w", vdp_reg[idx][:fb_base_addr  ] )
  mwrite( vdp_reg_base[idx] + 0x14, "w", vdp_reg[idx][:fb_stride     ] )
  mwrite( vdp_reg_base[idx] + 0x60, "w", vdp_reg[idx][:tpg__ctrl     ] )
  mwrite( vdp_reg_base[idx] + 0x64, "w", vdp_reg[idx][:tpg__width    ]<<16 | vdp_reg[idx][:tpg__height ])
end

vdp_id.each do |idx|
  vdp_reg_view[idx][:video__ctrl     ] = mread( vdp_reg_base[idx] + 0x04, "w" )
  vdp_reg_view[idx][:video__on       ] = (vdp_reg_view[idx][:video__ctrl][0] == 1)? true: false
  vdp_reg_view[idx][:video__format   ] = (vdp_reg_view[idx][:video__ctrl][5..4][0] == 0)? :rgba5650 : :rgba8880
  vdp_reg_view[idx][:video__intf     ] = pin_mux_id.invert[vdp_reg_view[idx][:video__ctrl][19..16]]
  vdp_reg_view[idx][:video__tpg_sel  ] = (vdp_reg_view[idx][:video__ctrl][20] == 1)? true: false

  vdp_reg_view[idx][:video__width    ] = mread( vdp_reg_base[idx] + 0x08, "w" )>>16
  vdp_reg_view[idx][:video__height   ] = mread( vdp_reg_base[idx] + 0x08, "w" )&0xffff
  vdp_reg_view[idx][:crop__X         ] = mread( vdp_reg_base[idx] + 0x0c, "w" )>>16
  vdp_reg_view[idx][:crop__Y         ] = mread( vdp_reg_base[idx] + 0x0c, "w" )&0xffff
  vdp_reg_view[idx][:fb_base_addr    ] = mread( vdp_reg_base[idx] + 0x10, "w" )
  vdp_reg_view[idx][:fb_stride       ] = mread( vdp_reg_base[idx] + 0x14, "w" )
  vdp_reg_view[idx][:start__X        ] = ((vdp_reg_view[idx][:fb_base_addr] - monitor[idx][:fb_base_addr]) % monitor[idx][:fb_stride]) / (monitor[idx][:bpp]/8)
  vdp_reg_view[idx][:start__Y        ] = ((vdp_reg_view[idx][:fb_base_addr] - monitor[idx][:fb_base_addr]) / monitor[idx][:fb_stride]) 

  vdp_reg_view[idx][:frm_count       ] = mread( vdp_reg_base[idx] + 0x18, "w" )
  vdp_reg_view[idx][:row_count       ] = mread( vdp_reg_base[idx] + 0x1c, "w" )>>16
  vdp_reg_view[idx][:col_count       ] = mread( vdp_reg_base[idx] + 0x1c, "w" )&0xffff
  vdp_reg_view[idx][:DECERR_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>24)&0xff
  vdp_reg_view[idx][:SLVERR_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>16)&0xff
  vdp_reg_view[idx][:EXOKAY_count    ] = (mread( vdp_reg_base[idx] + 0x20, "w" )>>8 )&0xff

  vdp_reg_view[idx][:axi_rd_req_cnt  ] = mread( vdp_reg_base[idx] + 0x30, "w" )
  vdp_reg_view[idx][:axi_rd_data_cnt ] = mread( vdp_reg_base[idx] + 0x34, "w" )
  vdp_reg_view[idx][:axi_rd_resp_cnt ] = mread( vdp_reg_base[idx] + 0x38, "w" )
  vdp_reg_view[idx][:axi_wr_req_cnt  ] = mread( vdp_reg_base[idx] + 0x40, "w" )
  vdp_reg_view[idx][:axi_wr_data_cnt ] = mread( vdp_reg_base[idx] + 0x44, "w" )
  vdp_reg_view[idx][:axi_wr_resp_cnt ] = mread( vdp_reg_base[idx] + 0x48, "w" )
  vdp_reg_view[idx][:axi_wr_bresp_cnt] = mread( vdp_reg_base[idx] + 0x4c, "w" )

  vdp_reg_view[idx][:tpg__ctrl       ] = mread( vdp_reg_base[idx] + 0x60, "w" )
  vdp_reg_view[idx][:tpg__on         ] = (vdp_reg_view[idx][:tpg__ctrl][28] == 1)? true: false
  vdp_reg_view[idx][:tpg__width      ] = mread( vdp_reg_base[idx] + 0x64, "w" )>>16
  vdp_reg_view[idx][:tpg__height     ] = mread( vdp_reg_base[idx] + 0x64, "w" )&0xffff

  vdp_reg_view[idx][:clock_denominator]= mread( vdp_reg_base[idx] + 0x70, "w" )

  puts "vdp_reg_view[#{idx}][:video__ctrl     ] = 0x%08x" % [ vdp_reg_view[idx][:video__ctrl     ]]
  puts "vdp_reg_view[#{idx}][:video__on       ] = %s"     % [ vdp_reg_view[idx][:video__on       ]]
  puts "vdp_reg_view[#{idx}][:video__format   ] = %s"     % [ vdp_reg_view[idx][:video__format   ]]
  puts "vdp_reg_view[#{idx}][:video__intf     ] = %s"     % [ vdp_reg_view[idx][:video__intf     ]]
  puts "vdp_reg_view[#{idx}][:video__tpg_sel  ] = %s"     % [ vdp_reg_view[idx][:video__tpg_sel  ]]

  puts "vdp_reg_view[#{idx}][:video__width    ] = %d"     % [ vdp_reg_view[idx][:video__width    ]]
  puts "vdp_reg_view[#{idx}][:video__height   ] = %d"     % [ vdp_reg_view[idx][:video__height   ]]
  puts "vdp_reg_view[#{idx}][:crop__X         ] = %d"     % [ vdp_reg_view[idx][:crop__X         ]]
  puts "vdp_reg_view[#{idx}][:crop__Y         ] = %d"     % [ vdp_reg_view[idx][:crop__Y         ]]
  puts "vdp_reg_view[#{idx}][:start__X        ] = %d"     % [ vdp_reg_view[idx][:start__X        ]]
  puts "vdp_reg_view[#{idx}][:start__Y        ] = %d"     % [ vdp_reg_view[idx][:start__Y        ]]
  puts "vdp_reg_view[#{idx}][:fb_base_addr    ] = 0x%08x" % [ vdp_reg_view[idx][:fb_base_addr    ]]
  puts "vdp_reg_view[#{idx}][:fb_stride       ] = 0x%08x" % [ vdp_reg_view[idx][:fb_stride       ]]

  puts "vdp_reg_view[#{idx}][:frm_count       ] = %d"     % [ vdp_reg_view[idx][:frm_count       ]]
  puts "vdp_reg_view[#{idx}][:row_count       ] = %d"     % [ vdp_reg_view[idx][:row_count       ]]
  puts "vdp_reg_view[#{idx}][:col_count       ] = %d"     % [ vdp_reg_view[idx][:col_count       ]]
  puts "vdp_reg_view[#{idx}][:DECERR_count    ] = %d"     % [ vdp_reg_view[idx][:DECERR_count    ]]
  puts "vdp_reg_view[#{idx}][:SLVERR_count    ] = %d"     % [ vdp_reg_view[idx][:SLVERR_count    ]]
  puts "vdp_reg_view[#{idx}][:EXOKAY_count    ] = %d"     % [ vdp_reg_view[idx][:EXOKAY_count    ]]

  puts "vdp_reg_view[#{idx}][:axi_rd_req_cnt  ] = %d"     % [ vdp_reg_view[idx][:axi_rd_req_cnt  ]]
  puts "vdp_reg_view[#{idx}][:axi_rd_data_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_rd_data_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_rd_resp_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_rd_resp_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_req_cnt  ] = %d"     % [ vdp_reg_view[idx][:axi_wr_req_cnt  ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_data_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_wr_data_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_resp_cnt ] = %d"     % [ vdp_reg_view[idx][:axi_wr_resp_cnt ]]
  puts "vdp_reg_view[#{idx}][:axi_wr_bresp_cnt] = %d"     % [ vdp_reg_view[idx][:axi_wr_bresp_cnt]]

  puts "vdp_reg_view[#{idx}][:tpg__ctrl       ] = 0x%08x" % [ vdp_reg_view[idx][:tpg__ctrl     ]]
  puts "vdp_reg_view[#{idx}][:tpg__on         ] = %s"     % [ vdp_reg_view[idx][:tpg__on]]
  puts "vdp_reg_view[#{idx}][:tpg__width      ] = %d"     % [ vdp_reg_view[idx][:tpg__width    ]]
  puts "vdp_reg_view[#{idx}][:tpg__height     ] = %d"     % [ vdp_reg_view[idx][:tpg__height   ]]

  puts "vdp_reg_view[#{idx}][:clock_denominator]= %d"     % [ vdp_reg_view[idx][:clock_denominator]]
  puts "vdp_reg_view[#{idx}][:vi_clk] = %3.2f MHz"        % [ (200.0/vdp_reg_view[idx][:clock_denominator])]
end

exit


######


