import mmap
import struct
import numpy as np
from PIL import Image
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description='virtual dispaly set tool')
    #parser.add_argument('case', type=str, help='Case to run')
    parser.add_argument('-V', '--address', type=str, help='virtual display address')
    parser.add_argument('-B', '--buffer', type=str, help='buffer address')
    parser.add_argument('-W', '--width', type=str, help='width')
    parser.add_argument('-H', '--height', type=str, help='height')
    parser.add_argument('-offset', '--offset', type=str, help='offset')
    args = parser.parse_args()
    args.parser = parser
    return args

def get_buffer_address(buffer):
    address = buffer.__array_interface__['data'][0]
    return hex(address)

def alloc_buffer(size):
    buffer = np.zeros(size, dtype=np.uint8)
    return buffer

def map_phy_addr(phy, buffer_addr, w, h, vdp_offset):
    with open('/dev/mem', 'r+b') as mem:
        offset = phy
        vdp_offset = vdp_offset
        size = 0x1000
        mem_mapped = mmap.mmap(mem.fileno(), size, offset=offset)
        #### clock
        data = 50
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[vdp_offset+0x70 : vdp_offset+0x70 + len(data_b)] = data_b
        #####w and h
        data = ((w << 16) & 0xFFFF0000) | (h & 0x0000FFFF)
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[vdp_offset+0x8 : vdp_offset+0x8 + len(data_b)] = data_b
        #### stride
        data = w * 4
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[vdp_offset+0x14 : vdp_offset+0x14 + len(data_b)] = data_b
        #### buffer addresee
        data = buffer_addr
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[vdp_offset+0x10 : vdp_offset+0x10 + len(data_b)] = data_b
        ### start
        #data = 0xd0011  for dsi_1.2
        #data = 0xc0011  for dp
        data = 0xc0011
        data_hex_str = format(data, '08X')
        data_b = bytes.fromhex(data_hex_str[0:])
        data_b = struct.pack('<I', int.from_bytes(data_b, 'big'))
        mem_mapped[vdp_offset+0x4 : vdp_offset+0x4 + len(data_b)] = data_b
        #data_bytes = mem_mapped.read(size)
        #data = np.frombuffer(data_bytes, dtype=np.uint8).reshape((h,w,4))
        mem_mapped.close()
        return

args = parse_args()
if args.address and args.width and args.height and args.buffer and args.offset:
    phy = int(args.address, 16)
    buffer_addr = int(args.buffer, 16)
    width = int(args.width)
    height = int(args.height)
    offset = int (args.offset, 16)
    map_phy_addr(phy, buffer_addr, width, height, offset)
else:
    print('dsadsa')
    args.parser.print_help()
